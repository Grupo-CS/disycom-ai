<?php
/*
Plugin Name: Generador IA con Galería
Description: Permite al usuario escribir un prompt para generar una imagen IA usando tu propia galería.
Version: 1.0
Author: Disycom
*/

function ai_generator_shortcode() {
    wp_enqueue_style('ai-generator-style', plugins_url('/css/ai-generator.css', __FILE__));
    wp_enqueue_script('ai-generator-script', plugins_url('/js/ai-generator.js', __FILE__), array('jquery'), null, true);

    ob_start(); ?>
    <div class="contenedor-ia">
        <h2>Genera una imagen con IA basada en nuestra galería</h2>
        <form id="formularioIA">
            <input type="text" id="prompt" placeholder="Describe lo que quieres ver..." required>
            <button type="submit">Generar</button>
        </form>
        <div class="resultado" id="resultadoIA">
            <!-- Resultados aquí -->
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('generador_ia', 'ai_generator_shortcode');
