document.addEventListener("DOMContentLoaded", function () {
  const formulario = document.getElementById("formularioIA");
  const resultado = document.getElementById("resultadoIA");

  formulario.addEventListener("submit", async function (e) {
    e.preventDefault();
    const prompt = document.getElementById("prompt").value;
    resultado.innerHTML = "Generando imagen... ⏳";

    try {
      const response = await fetch("https://abc123.ngrok.io/generar-imagen-ia", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ prompt: prompt })
      });

      const data = await response.json();

      resultado.innerHTML = `
        <div>
          <div class="label">Imagen original</div>
          <img src="${data.original}" alt="Imagen base">
        </div>
        <div>
          <div class="label">Imagen generada</div>
          <img src="${data.generada}" alt="Imagen generada por IA">
        </div>
      `;
    } catch (error) {
      resultado.innerHTML = "Ocurrió un error al generar la imagen.";
    }
  });
});
